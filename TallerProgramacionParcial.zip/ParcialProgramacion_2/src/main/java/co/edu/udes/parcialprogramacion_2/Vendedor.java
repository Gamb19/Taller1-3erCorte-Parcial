/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.parcialprogramacion_2;

import java.util.ArrayList;

/**
 *
 * @author molin
 */
public class Vendedor extends Empleado {
    private Coche coche;
    private String areaVenta;
    private ArrayList<Cliente> listaClientes;
    private double comision;

    public Vendedor(String nombre, String apellido, int DNI, String direccion, int telefono, double salario, Coche coche, String areaVenta, double comision) {
        super(nombre, apellido, DNI, direccion, telefono, salario);
        this.coche = coche;
        this.areaVenta = areaVenta;
        this.listaClientes = new ArrayList<Cliente>();
        this.comision = comision;
    }

    public Coche getCoche() {
        return coche;
    }

    public void setCoche(Coche coche) {
        this.coche = coche;
    }

    public String getAreaVenta() {
        return areaVenta;
    }

    public void setAreaVenta(String areaVenta) {
        this.areaVenta = areaVenta;
    }

    public ArrayList<Cliente> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }

    public double getComision() {
        return comision;
    }

    public void setComision(double comision) {
        this.comision = comision;
    }

    @Override
    public String toString() {
        return super.toString() + ", Carro " + coche.toString() + ", Area de Venta: " + areaVenta;
    }

    public void darDeAltaCliente(Cliente cliente) {
        listaClientes.add(cliente);
    }

    public void darDeBajaCliente(Cliente cliente) {
        listaClientes.remove(cliente);
    }

    public void cambiarCoche(Coche coche) {
        this.coche = coche;
    }

    @Override
    public void incrementarSalario(double incremento) {
        super.incrementarSalario(incremento * 1.1);
    }

    public void imprimir() {
        System.out.println("Nombre: " + getNombre());
        System.out.println("Apellido: " + getApellido());
        System.out.println("DNI: " + getDNI());
        System.out.println("Direccion: " + getDireccion());
        System.out.println("Telefono: " + getTelefono());
        System.out.println("Carro: " + getCoche());
        System.out.println("Salario: " + getSalario());
        System.out.println("Puesto en la empresa: Vendedor");
        System.out.println("Clientes:");
        for (Cliente c : listaClientes) {
            System.out.println(c.toString());
        }
    }
}
