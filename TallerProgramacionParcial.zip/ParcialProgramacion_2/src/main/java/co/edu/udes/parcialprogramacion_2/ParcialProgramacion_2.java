/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package co.edu.udes.parcialprogramacion_2;

import java.util.List;
import java.util.*;

/**
 *
 * @author molin
 */
public class ParcialProgramacion_2 {

    public static void main(String[] args) {
        Secretario secretario1 = new Secretario("Bartolo", "Bartolome", 12345678, "Los patios", 213312312, 1000000, "Despacho 1", "213");
        Secretario secretario2 = new Secretario("Yander", "Kleiver", 1098765432, "El zulia", 92181201, 2500, "Despacho 2", "2112");

        Coche carrito1 = new Coche("SBF 62O", "TOYOTA", "Supra");
        Coche carrito2 = new Coche("HBF 55A", "FIAT", "SIENA");
        Coche carrito3 = new Coche("KLM 90A", "Mitsubishi", "Lancer");
        Vendedor vendedor1 = new Vendedor("Gabriel", "Molina", 82317946, "Agua salud", 04144563112, 100000, carrito3, "Zona 1", 20);
        Vendedor vendedor2 = new Vendedor("Simon", "Bolivar", 01010101, "CARICUAO", 213213213, 350023, carrito1, "Zona 2", 15);

        List<Vendedor> vendedores = new ArrayList<>();
        vendedores.add(vendedor2);

        JefeZona jz1 = new JefeZona(secretario2, carrito2, vendedores, "Nicolas", "Maduros", 01010123, "CAPITOLIO-PINTOSALINA", 23131, 92191);

        //Datos:
        System.out.println("Datos de los empleados:");
        System.out.println("--------------------------------------------------");
        System.out.println("Secreatarios: \n");
        secretario1.imprimir();
        System.out.println("--------------------------------------------------");
        secretario2.imprimir();
        System.out.println("--------------------------------------------------");
        System.out.println("Vendedores: \n");
        vendedor1.imprimir();
        System.out.println("--------------------------------------------------");
        vendedor2.imprimir();
        System.out.println("--------------------------------------------------");
        System.out.println("Jefe de zona: \n");
        jz1.imprimir();
        System.out.println("--------------------------------------------------");

        // Cambio de supervisor de algun vendedor
        System.out.println("Cambiando el supervisor de " + vendedor1.getNombre() + ":");
        vendedor1.cambiarSupervisor(secretario2);
        System.out.println("Nuevo Supervisor: " + vendedor1 + ": " + vendedor1.getSupervisor().getNombre());
        System.out.println("--------------------------------------------------");

        // Probando que el metodo Incrementar salario funcione
        System.out.println("Incremento salario: ");
        secretario1.incrementarSalario(100);
        vendedor2.incrementarSalario(200);
        jz1.incrementarSalario(400);
        System.out.println("--------------------------------------------------");

        System.out.println("Nuevos datos de los empleados con el incremento de salario:");
        System.out.println("--------------------------------------------------");
        secretario1.imprimir();
        System.out.println("--------------------------------------------------");
        vendedor2.imprimir();
        System.out.println("--------------------------------------------------");
        jz1.imprimir();
        System.out.println("--------------------------------------------------");

        System.out.println("Cambio de carro de: " + vendedor1.getNombre() + ":");
        vendedor1.cambiarCoche(carrito2);
        System.out.println("Nuevo carro de " + vendedor1.getNombre() + ": " + vendedor1.getCoche().getMatricula() + " " + vendedor1.getCoche().getMarca() + " " + vendedor1.getCoche().getModelo());

        System.out.println("Cambio de carro de: " + jz1.getNombre() + ":");
        jz1.cambiarCoche(carrito3);
        System.out.println("Nuevo carro de: " + jz1.getNombre() + ":" + jz1.getCoche().getMatricula() + " " + jz1.getCoche().getMarca() + " " + jz1.getCoche().getModelo());
        
        List<Cliente> clientes = new ArrayList<>();
   
        
        Cliente cliente1 = new Cliente("Juan", "Molina", 12345, "Artiga", 345212123);
        clientes.add(cliente1);

        Cliente cliente2 = new Cliente("ojito", "borges", 12345, "Artiga", 345212123);
        clientes.add(cliente2);

        System.out.println("Datos de los clientes:");
        System.out.println("-----------------------");
        for (Cliente cliente : clientes) {
            cliente.imprimir();
            System.out.println("-----------------------");
        }

        // Dar de baja un cliente
        System.out.println("Dando de baja al cliente " + cliente1.getNombre() + ":");
        clientes.remove(cliente1);

        // Datos actualizados de los clientes
        System.out.println("Datos actualizados de los clientes:");
        System.out.println("-----------------------------------");
        for (Cliente cliente : clientes) {
            cliente.imprimir();
            System.out.println("-----------------------");
        }
        // Dar de alta un cliente
        System.out.println("Dando de alta a un nuevo cliente:");
        Cliente nuevoCliente = new Cliente("Albertico", "Medina", 12345, "Artiga", 345212123);
        clientes.add(nuevoCliente);

        // Datos actualizados de los clientes
        System.out.println("Datos actualizados de los clientes:");
        System.out.println("-----------------------------------");
        for (Cliente cliente : clientes) {
            cliente.imprimir();
            System.out.println("-----------------------");
        }

    }
}
